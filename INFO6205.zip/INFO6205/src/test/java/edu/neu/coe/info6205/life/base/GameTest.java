package edu.neu.coe.info6205.life.base;

import org.junit.Test;

public class GameTest {

    @Test
    public void run() {
        // TODO implement test
    }

    @Test
    public void generation() {
        // TODO implement test
    }
}